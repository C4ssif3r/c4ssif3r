from cipherx.client import ClientRubika
from rich import print as prints
import asyncio

auth = [
#  لیست AUTH

]

bot = ClientRubika('CipherX') # چیزی نزارید داخلش

async def main():
    for authX in auth:
        try:
            status = bot.online(authX)
            prints(f"""
=========================\n
{status}\n
AUTH => "{authX}"\n

""")
        except:
            pass

asyncio.run(main())




